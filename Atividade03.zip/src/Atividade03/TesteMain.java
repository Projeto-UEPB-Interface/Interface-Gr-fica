package Atividade03;

import java.awt.EventQueue;

public class TesteMain {
    public boolean c = false;
    public static void main(String args[]) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Tela().setVisible(true);
            }
        });
    }
}