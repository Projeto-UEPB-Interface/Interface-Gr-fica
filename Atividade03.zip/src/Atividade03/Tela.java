package Atividade03;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Tela extends javax.swing.JFrame {
    public static boolean cTextField = false;
    public static String digitar = new String("");
    
    public Tela() {
        PainelPrincipal panel = new PainelPrincipal();
        add(panel);
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        addKeyListener(new KeyAdapter(){
            public void keyPressed(KeyEvent event){
                if(cTextField == true) {
                    digitar += event.getKeyChar();
                    repaint();
                }
            }
        });
    }
}